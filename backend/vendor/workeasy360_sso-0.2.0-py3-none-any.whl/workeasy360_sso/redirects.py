"""``next`` is a same-site path, or it is ignored (completion-design 3.8)."""

from __future__ import annotations

from django.urls import NoReverseMatch, reverse

MAX_NEXT_LENGTH = 2048


def _auth_paths() -> tuple[str, ...]:
    from django.shortcuts import resolve_url

    from workeasy360_sso.conf import get_config

    paths = []
    for name in ("start", "callback", "logout", "logout_workeasy360", "backchannel_logout"):
        try:
            paths.append(reverse(f"workeasy360_sso:{name}"))
        except NoReverseMatch:
            continue
    try:
        login = resolve_url(get_config().login_url)
        if login.startswith("/"):
            paths.append(login)
    except NoReverseMatch:
        pass
    return tuple(paths)


def safe_next(value: str | None, *, default: str = "/") -> str:
    """``value`` if it is a safe same-site path, else ``default``.

    Starts with ``/`` but not ``//``; no backslash, whitespace or control
    character (each has been an open-redirect bypass somewhere); at most
    2,048 characters; not one of the connector's own sign-in endpoints, so a
    sign-in can never "continue" into another sign-in.
    """
    if not value or not isinstance(value, str) or len(value) > MAX_NEXT_LENGTH:
        return default
    if not value.startswith("/") or value.startswith("//"):
        return default
    if "\\" in value or any(ch.isspace() or ord(ch) < 32 or ord(ch) == 127 for ch in value):
        return default
    path = value.split("?", 1)[0].split("#", 1)[0]
    if path in _auth_paths():
        return default
    return value
