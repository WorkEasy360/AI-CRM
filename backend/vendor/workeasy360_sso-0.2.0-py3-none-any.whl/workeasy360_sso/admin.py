from django.contrib import admin

from workeasy360_sso.models import FederatedIdentity, ProductSession


@admin.register(FederatedIdentity)
class FederatedIdentityAdmin(admin.ModelAdmin):
    list_display = ("subject", "user", "status", "linked_at", "last_sign_in_at")
    list_filter = ("status",)
    search_fields = ("subject", "email_at_link")
    readonly_fields = ("issuer", "subject", "user", "email_at_link", "linked_at", "last_sign_in_at")

    def has_add_permission(self, request):
        # Links are made by a verified sign-in, never typed in.
        return False


@admin.register(ProductSession)
class ProductSessionAdmin(admin.ModelAdmin):
    list_display = ("identity", "organization_id", "created_at", "ended_at", "end_reason")
    list_filter = ("end_reason",)
    readonly_fields = [f.name for f in ProductSession._meta.fields]

    def has_add_permission(self, request):
        return False
