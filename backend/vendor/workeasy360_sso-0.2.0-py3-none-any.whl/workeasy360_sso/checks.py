"""Django system checks: a misconfiguration is found at deploy, not by a user.

``manage.py check --deploy`` runs them all. ``apps.ready`` additionally
refuses to start an SSO-only production process with an invalid
configuration, because gunicorn does not run system checks.
"""

from __future__ import annotations

from urllib.parse import urlsplit

from django.conf import settings
from django.core.checks import Error, Tags, Warning, register
from django.urls import NoReverseMatch, reverse

from workeasy360_sso.conf import ConfigurationError, get_config

BACKEND = "workeasy360_sso.backends.WorkEasy360Backend"
MIDDLEWARE = "workeasy360_sso.middleware.SSOMiddleware"
TRACKING_MIDDLEWARE = "workeasy360_sso.middleware.SessionTrackingMiddleware"
AUTH_MIDDLEWARE = "django.contrib.auth.middleware.AuthenticationMiddleware"
SESSION_MIDDLEWARE = "django.contrib.sessions.middleware.SessionMiddleware"


@register(Tags.security, deploy=False)
def check_configuration(app_configs=None, **kwargs):
    messages = []
    try:
        config = get_config()
    except ConfigurationError as exc:
        return [Error(str(exc), id="workeasy360_sso.E001")]

    # Nothing configured at all, and Workeasy360 is not the only way in: sign-in is simply off (a test run,
    # a deployment that has not adopted it yet). Every "X is required" would be noise.
    switched_off = not config.sso_only and not (
        config.issuer or config.client_id or config.redirect_uri
    )
    for problem in () if switched_off else config.problems:
        level = Error if config.sso_only else Warning
        messages.append(
            level(
                problem,
                hint="See workeasy360-sso README, 'Configuration'.",
                id="workeasy360_sso.E001" if config.sso_only else "workeasy360_sso.W001",
            )
        )

    if config.login_backend not in getattr(settings, "AUTHENTICATION_BACKENDS", []):
        messages.append(
            Error(
                f"{config.login_backend} must be listed in AUTHENTICATION_BACKENDS.",
                hint="Django loads signed-in users through the backend that signed them in.",
                id="workeasy360_sso.E002",
            )
        )

    middleware = list(getattr(settings, "MIDDLEWARE", []))
    if MIDDLEWARE in middleware:
        if AUTH_MIDDLEWARE not in middleware or middleware.index(MIDDLEWARE) < middleware.index(
            AUTH_MIDDLEWARE
        ):
            messages.append(
                Error(
                    f"{MIDDLEWARE} must come after {AUTH_MIDDLEWARE}.",
                    id="workeasy360_sso.E003",
                )
            )
        if TRACKING_MIDDLEWARE in middleware:
            messages.append(
                Error(
                    f"Install {MIDDLEWARE} or {TRACKING_MIDDLEWARE}, not both.",
                    id="workeasy360_sso.E003",
                )
            )
    elif TRACKING_MIDDLEWARE in middleware:
        if SESSION_MIDDLEWARE not in middleware or middleware.index(
            TRACKING_MIDDLEWARE
        ) < middleware.index(SESSION_MIDDLEWARE):
            messages.append(
                Error(
                    f"{TRACKING_MIDDLEWARE} must come after {SESSION_MIDDLEWARE}.",
                    id="workeasy360_sso.E003",
                )
            )
    else:
        messages.append(
            Warning(
                f"{MIDDLEWARE} is not installed: no automatic sign-in and no entitlement "
                "re-check while a session lasts.",
                hint=f"A product that does both itself installs {TRACKING_MIDDLEWARE}, so "
                "back-channel logout follows rotated session keys.",
                id="workeasy360_sso.W003",
            )
        )

    engine = getattr(settings, "SESSION_ENGINE", "")
    if config.backchannel_logout and engine == "django.contrib.sessions.backends.signed_cookies":
        messages.append(
            Error(
                "Back-channel logout needs a server-side session engine; signed-cookie "
                "sessions cannot be ended from the server.",
                hint="Use the db, cache or cached_db session engine, or set "
                "WORKEASY360_BACKCHANNEL_LOGOUT=false.",
                id="workeasy360_sso.E004",
            )
        )

    if config.redirect_uri:
        try:
            callback = reverse("workeasy360_sso:callback")
        except NoReverseMatch:
            messages.append(
                Error(
                    "No workeasy360_sso:callback route: the registered redirect URI is served "
                    "by nothing.",
                    hint='path("auth/workeasy360/", include("workeasy360_sso.urls")), or your '
                    "own callback view named \"callback\" in workeasy360_sso.urls.namespaced()",
                    id="workeasy360_sso.E005",
                )
            )
        else:
            registered = urlsplit(config.redirect_uri).path
            if registered != callback:
                messages.append(
                    Error(
                        f"WORKEASY360_REDIRECT_URI path {registered!r} is not the callback "
                        f"route {callback!r}.",
                        hint="Redirect URIs are compared by exact string equality.",
                        id="workeasy360_sso.E005",
                    )
                )

    if config.allow_insecure_http and not settings.DEBUG:
        messages.append(
            Warning(
                "WORKEASY360_ALLOW_INSECURE_HTTP is on outside DEBUG. It permits http only "
                "on loopback hosts; production should not set it.",
                id="workeasy360_sso.W002",
            )
        )
    return messages
