"""Configuration: one validated, immutable object per process.

Values come from ``settings.WORKEASY360_SSO`` (a dict with upper-case keys)
and fall back to ``WORKEASY360_<KEY>`` environment variables, which are the
names the Workeasy360 integration guide already documents for products. A
product deployed from the starter template sets only environment variables.

Nothing here is product specific: the product is whatever ``PRODUCT_CODE``
and ``CLIENT_ID`` say it is.
"""

from __future__ import annotations

import ipaddress
import os
import re
import threading
from collections.abc import Mapping
from dataclasses import dataclass
from functools import cached_property
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from django.conf import settings
from django.core.signals import setting_changed
from django.utils.module_loading import import_string

#: Scopes asked for by default. ``openid`` yields the subject, organization and
#: product binding; ``email``/``profile``/``organization`` must also be
#: registered for the product's integration or the provider answers
#: ``invalid_scope``.
DEFAULT_SCOPES: tuple[str, ...] = ("openid", "email", "profile", "organization")

#: The only signing algorithms the platform uses (contract 04 section 1).
SUPPORTED_ALGORITHMS = frozenset({"RS256", "ES256"})

#: ``prompt`` values a product may request (OIDC Core 3.1.2.1, contract 04).
ALLOWED_PROMPTS = frozenset({"none", "login", "consent", "select_account"})

PRODUCT_CODE_RE = re.compile(r"^[a-z][a-z0-9_]{1,31}$")

#: The backend a sign-in is recorded under unless the product names its own.
DEFAULT_LOGIN_BACKEND = "workeasy360_sso.backends.WorkEasy360Backend"

#: A product-defined refusal code: safe in a URL, a log line and a template.
ERROR_CODE_RE = re.compile(r"^[a-z][a-z0-9_]{1,63}$")

_TRUE = {"1", "true", "yes", "on"}
_FALSE = {"0", "false", "no", "off", ""}


class ConfigurationError(Exception):
    """The connector cannot run with the configuration it was given."""


@dataclass(frozen=True)
class SSOConfig:
    issuer: str
    client_id: str
    redirect_uri: str
    product_code: str
    key_id: str
    private_key_pem: str
    signing_algorithm: str
    client_secret: str
    post_logout_redirect_uri: str
    scopes: tuple[str, ...]
    sso_only: bool
    auto_start: bool
    enforce_entitlement: bool
    backchannel_logout: bool
    api_path_prefixes: tuple[str, ...]
    public_paths: tuple[str, ...]
    login_url: str
    login_redirect_url: str
    logout_redirect_url: str
    purchase_url: str
    error_redirect_url: str
    http_timeout: float
    discovery_ttl: int
    leeway: int
    flow_ttl: int
    user_adapter: str
    organization_adapter: str
    link_by_verified_email: bool
    sync_profile: bool
    cache_alias: str
    allow_insecure_http: bool
    expose_status: bool
    http_transport: Any
    #: The authentication backend ``login()`` records a sign-in under. A product
    #: that already signs people in through its own backend names it here, so
    #: sessions look the same whichever way the person came in.
    login_backend: str = DEFAULT_LOGIN_BACKEND
    #: Product-defined refusal codes and their messages, as ``(code, message)``.
    product_error_messages: tuple[tuple[str, str], ...] = ()
    #: Timeout for entitlement questions, which a waiting request (often inside
    #: its database transaction) or a job pays for. Defaults to ``http_timeout``.
    entitlement_timeout: float = 5.0
    #: Exception types (dotted paths) that must never be read as a provider
    #: outage, e.g. a task runner's "time is up" signal.
    propagate_exceptions: tuple[str, ...] = ()

    @property
    def uses_private_key_jwt(self) -> bool:
        return bool(self.private_key_pem)

    @property
    def error_messages(self) -> dict[str, str]:
        return dict(self.product_error_messages)

    @cached_property
    def propagated_exception_types(self) -> tuple[type[BaseException], ...]:
        types: list[type[BaseException]] = []
        for name in self.propagate_exceptions:
            try:
                found = import_string(name)
            except ImportError:
                continue  # reported by validate()
            if isinstance(found, type) and issubclass(found, BaseException):
                types.append(found)
        return tuple(types)

    @cached_property
    def problems(self) -> tuple[str, ...]:
        """Validated once per configuration object (it parses the key)."""
        return tuple(validate(self))

    @property
    def is_configured(self) -> bool:
        return not self.problems

    @property
    def scope(self) -> str:
        return " ".join(self.scopes)


# --- loading ----------------------------------------------------------------

_lock = threading.Lock()
_cached: SSOConfig | None = None


def get_config() -> SSOConfig:
    """The process-wide configuration, built once and cached."""
    global _cached
    config = _cached
    if config is None:
        with _lock:
            if _cached is None:
                _cached = _load()
            config = _cached
    return config


def reset_config() -> None:
    """Forget the cached configuration (tests, and ``setting_changed``)."""
    global _cached
    with _lock:
        _cached = None


def _on_setting_changed(*, setting: str, **_: Any) -> None:
    if setting in {
        "WORKEASY360_SSO",
        "LOGIN_URL",
        "LOGIN_REDIRECT_URL",
        "LOGOUT_REDIRECT_URL",
        "DEBUG",
    }:
        reset_config()
        from workeasy360_sso import discovery

        discovery.reset_cache()


setting_changed.connect(_on_setting_changed)


def _raw(key: str, default: Any = None) -> Any:
    explicit = _explicit()
    if key in explicit:
        return explicit[key]
    env = os.environ.get(f"WORKEASY360_{key}")
    if env is not None:
        return env
    return default


def _str(key: str, default: str = "") -> str:
    value = _raw(key, default)
    return "" if value is None else str(value).strip()


def _bool(key: str, default: bool) -> bool:
    value = _raw(key, None)
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    lowered = str(value).strip().lower()
    if lowered in _TRUE:
        return True
    if lowered in _FALSE:
        return False
    raise ConfigurationError(f"WORKEASY360_{key} must be a boolean, not {value!r}.")


def _int(key: str, default: int) -> int:
    value = _raw(key, None)
    if value is None or value == "":
        return default
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise ConfigurationError(f"WORKEASY360_{key} must be an integer.") from exc


def _float(key: str, default: float) -> float:
    value = _raw(key, None)
    if value is None or value == "":
        return default
    try:
        return float(value)
    except (TypeError, ValueError) as exc:
        raise ConfigurationError(f"WORKEASY360_{key} must be a number of seconds.") from exc


def _tuple(key: str, default: tuple[str, ...]) -> tuple[str, ...]:
    value = _raw(key, None)
    if value is None:
        return default
    if isinstance(value, (list, tuple)):
        items = [str(v).strip() for v in value]
    else:
        items = [part.strip() for part in re.split(r"[\s,]+", str(value))]
    return tuple(item for item in items if item)


def _explicit() -> Mapping[str, Any]:
    explicit = getattr(settings, "WORKEASY360_SSO", None) or {}
    return explicit if isinstance(explicit, Mapping) else {}


def _error_messages() -> tuple[tuple[str, str], ...]:
    value = _explicit().get("ERROR_MESSAGES")
    if not value:
        return ()
    if not isinstance(value, Mapping):
        raise ConfigurationError("WORKEASY360_SSO['ERROR_MESSAGES'] must map codes to messages.")
    return tuple((str(code), str(message)) for code, message in value.items())


def _dotted_paths(key: str) -> tuple[str, ...]:
    value = _explicit().get(key)
    if value is None:
        return _tuple(key, ())
    if isinstance(value, (str, type)):
        value = [value]
    paths = []
    for item in value:
        if isinstance(item, type):
            paths.append(f"{item.__module__}.{item.__qualname__}")
        else:
            paths.append(str(item).strip())
    return tuple(path for path in paths if path)


def _signing_algorithm(private_key_pem: str) -> str:
    """``SIGNING_ALGORITHM`` if set; otherwise the one the private key implies.

    An EC P-256 key signs ES256 and anything else RS256, so a product cannot
    configure a key and an algorithm that disagree by leaving one out.
    """
    explicit = _str("SIGNING_ALGORITHM")
    if explicit:
        return explicit.upper()
    if private_key_pem:
        from cryptography.hazmat.primitives.asymmetric import ec
        from cryptography.hazmat.primitives.serialization import load_pem_private_key

        try:
            key = load_pem_private_key(private_key_pem.encode("ascii"), password=None)
        except (ValueError, TypeError, UnicodeEncodeError):
            return "RS256"  # validate() reports the unusable key
        if isinstance(key, ec.EllipticCurvePrivateKey) and key.curve.name == "secp256r1":
            return "ES256"
    return "RS256"


def _private_key() -> str:
    literal = _str("PRIVATE_KEY")
    if literal:
        # Environment variables cannot hold newlines everywhere; the platform
        # guide allows a literal ``\n`` in WORKEASY360_PRIVATE_KEY.
        return literal.replace("\\n", "\n")
    path = _str("PRIVATE_KEY_FILE")
    if path:
        try:
            return Path(path).read_text(encoding="ascii")
        except OSError as exc:
            raise ConfigurationError(
                "WORKEASY360_PRIVATE_KEY_FILE could not be read."
            ) from exc
    return ""


def _load() -> SSOConfig:
    sso_only = _bool("SSO_ONLY", False)
    explicit = _explicit()
    private_key_pem = _private_key()
    http_timeout = _float("HTTP_TIMEOUT", 5.0)
    return SSOConfig(
        issuer=_str("ISSUER"),
        client_id=_str("CLIENT_ID"),
        redirect_uri=_str("REDIRECT_URI"),
        product_code=_str("PRODUCT_CODE"),
        key_id=_str("KEY_ID"),
        private_key_pem=private_key_pem,
        signing_algorithm=_signing_algorithm(private_key_pem),
        client_secret=_str("CLIENT_SECRET"),
        post_logout_redirect_uri=_str("POST_LOGOUT_REDIRECT_URI"),
        scopes=_tuple("SCOPES", DEFAULT_SCOPES),
        sso_only=sso_only,
        auto_start=_bool("AUTO_START", sso_only),
        enforce_entitlement=_bool("ENFORCE_ENTITLEMENT", True),
        backchannel_logout=_bool("BACKCHANNEL_LOGOUT", True),
        api_path_prefixes=_tuple("API_PATH_PREFIXES", ("/api/",)),
        public_paths=_tuple("PUBLIC_PATHS", ()),
        login_url=_str("LOGIN_URL", str(getattr(settings, "LOGIN_URL", "/accounts/login/"))),
        login_redirect_url=_str(
            "LOGIN_REDIRECT_URL", str(getattr(settings, "LOGIN_REDIRECT_URL", "/"))
        ),
        logout_redirect_url=_str(
            "LOGOUT_REDIRECT_URL",
            str(getattr(settings, "LOGOUT_REDIRECT_URL", None) or "/"),
        ),
        purchase_url=_str("PURCHASE_URL"),
        error_redirect_url=_str("ERROR_REDIRECT_URL"),
        http_timeout=http_timeout,
        discovery_ttl=_int("DISCOVERY_TTL", 3600),
        leeway=_int("LEEWAY", 30),
        flow_ttl=_int("FLOW_TTL", 600),
        user_adapter=_str("USER_ADAPTER", "workeasy360_sso.provisioning.DefaultUserAdapter"),
        organization_adapter=_str(
            "ORGANIZATION_ADAPTER", "workeasy360_sso.organizations.DefaultOrganizationAdapter"
        ),
        link_by_verified_email=_bool("LINK_BY_VERIFIED_EMAIL", False),
        sync_profile=_bool("SYNC_PROFILE", True),
        cache_alias=_str("CACHE_ALIAS", "default"),
        allow_insecure_http=_bool("ALLOW_INSECURE_HTTP", False),
        expose_status=_bool("EXPOSE_STATUS", True),
        # Only settable from Python: an httpx transport for tests or proxies.
        http_transport=explicit.get("HTTP_TRANSPORT"),
        login_backend=_str("LOGIN_BACKEND", DEFAULT_LOGIN_BACKEND),
        product_error_messages=_error_messages(),
        entitlement_timeout=_float("ENTITLEMENT_TIMEOUT", http_timeout),
        propagate_exceptions=_dotted_paths("PROPAGATE_EXCEPTIONS"),
    )


# --- validation -------------------------------------------------------------


def is_loopback_host(host: str) -> bool:
    host = (host or "").strip("[]").lower()
    if host == "localhost" or host.endswith(".localhost"):
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def url_problem(value: str, *, allow_insecure_http: bool, allow_query: bool = False) -> str:
    """Why ``value`` is not an acceptable absolute URL, or ``""``.

    The same allowlist the platform applies to registered URLs (manifest
    section 2): https, or http on a loopback host when explicitly allowed for
    local development; no userinfo, no fragment, no wildcard.
    """
    if not value:
        return "is empty"
    try:
        parts = urlsplit(value)
    except ValueError:
        return "is not a URL"
    if parts.scheme == "http":
        if not (allow_insecure_http and is_loopback_host(parts.hostname or "")):
            return "must use https (http is allowed only on a loopback host in development)"
    elif parts.scheme != "https":
        return "must use https"
    if not parts.hostname:
        return "has no host"
    if parts.username or parts.password or "@" in parts.netloc:
        return "must not contain user information"
    if parts.fragment or value.endswith("#"):
        return "must not contain a fragment"
    if parts.query and not allow_query:
        return "must not contain a query string"
    if "*" in value:
        return "must not contain a wildcard"
    return ""


def validate(config: SSOConfig) -> list[str]:
    """Every problem with ``config``. Empty means the connector can run."""
    problems: list[str] = []
    insecure = config.allow_insecure_http

    if not config.issuer:
        problems.append("WORKEASY360_ISSUER is required.")
    else:
        issue = url_problem(config.issuer, allow_insecure_http=insecure)
        if issue:
            problems.append(f"WORKEASY360_ISSUER {issue}.")
        if config.issuer.endswith("/"):
            # The ``iss`` claim is compared by exact string equality.
            problems.append("WORKEASY360_ISSUER must not end with '/'.")

    if not config.client_id:
        problems.append("WORKEASY360_CLIENT_ID is required.")

    if not config.product_code:
        problems.append("WORKEASY360_PRODUCT_CODE is required.")
    elif not PRODUCT_CODE_RE.match(config.product_code):
        problems.append("WORKEASY360_PRODUCT_CODE must be 2-32 of [a-z0-9_], starting a-z.")

    if not config.redirect_uri:
        problems.append("WORKEASY360_REDIRECT_URI is required.")
    else:
        issue = url_problem(config.redirect_uri, allow_insecure_http=insecure)
        if issue:
            problems.append(f"WORKEASY360_REDIRECT_URI {issue}.")

    if config.post_logout_redirect_uri:
        issue = url_problem(config.post_logout_redirect_uri, allow_insecure_http=insecure)
        if issue:
            problems.append(f"WORKEASY360_POST_LOGOUT_REDIRECT_URI {issue}.")

    if config.private_key_pem and config.client_secret:
        problems.append(
            "Configure exactly one client credential: a private key (recommended) "
            "or a client secret, not both."
        )
    elif config.private_key_pem:
        if not config.key_id:
            problems.append("WORKEASY360_KEY_ID is required with a private key.")
        if config.signing_algorithm not in SUPPORTED_ALGORITHMS:
            problems.append("WORKEASY360_SIGNING_ALGORITHM must be RS256 or ES256.")
        else:
            problems.extend(_private_key_problems(config))
    elif not config.client_secret:
        problems.append(
            "A client credential is required: WORKEASY360_PRIVATE_KEY_FILE (or "
            "WORKEASY360_PRIVATE_KEY) with WORKEASY360_KEY_ID, or WORKEASY360_CLIENT_SECRET."
        )

    if "openid" not in config.scopes:
        problems.append("WORKEASY360_SCOPES must include 'openid'.")

    if not 0 <= config.leeway <= 60:
        problems.append("WORKEASY360_LEEWAY must be between 0 and 60 seconds.")
    if not 60 <= config.flow_ttl <= 900:
        problems.append("WORKEASY360_FLOW_TTL must be between 60 and 900 seconds.")
    if not (0 < config.http_timeout <= 60 and 0 < config.entitlement_timeout <= 60):
        problems.append(
            "WORKEASY360_HTTP_TIMEOUT and WORKEASY360_ENTITLEMENT_TIMEOUT must be 0-60 seconds."
        )
    for code, _message in config.product_error_messages:
        if not ERROR_CODE_RE.match(code):
            problems.append(f"ERROR_MESSAGES code {code!r} must be 2-64 of [a-z0-9_], starting a-z.")
    for name in config.propagate_exceptions:
        try:
            found = import_string(name)
        except ImportError:
            problems.append(f"PROPAGATE_EXCEPTIONS: {name!r} cannot be imported.")
            continue
        if not (isinstance(found, type) and issubclass(found, BaseException)):
            problems.append(f"PROPAGATE_EXCEPTIONS: {name!r} is not an exception type.")
    return problems


def _private_key_problems(config: SSOConfig) -> list[str]:
    from cryptography.hazmat.primitives.asymmetric import ec, rsa
    from cryptography.hazmat.primitives.serialization import load_pem_private_key

    try:
        key = load_pem_private_key(config.private_key_pem.encode("ascii"), password=None)
    except (ValueError, TypeError):
        return ["The private key is not an unencrypted PEM private key."]
    if config.signing_algorithm == "RS256":
        if not isinstance(key, rsa.RSAPrivateKey):
            return ["RS256 needs an RSA private key."]
        if key.key_size < 2048:
            return ["The RSA private key must be at least 2048 bits."]
    if config.signing_algorithm == "ES256":
        if not isinstance(key, ec.EllipticCurvePrivateKey) or key.curve.name != "secp256r1":
            return ["ES256 needs a P-256 elliptic-curve private key."]
    return []
