"""Signals a product can connect to. Nothing in the connector depends on a receiver.

``backchannel_logout``
    Sent by the back-channel logout receiver after it verified a logout token,
    recorded its ``jti`` and ended the product sessions the connector tracks
    for it, **inside the same database transaction**. A receiver that raises
    rolls all of it back and the provider is answered ``503``, so it delivers
    the token again. Use it to end sessions the product tracks itself - for
    example every session of that person, including ones opened before the
    product used this connector, when the token names only ``sub``
    ("sign out everywhere").

    Keyword arguments: ``request``, ``issuer``, ``subject`` (``""`` when the
    token names none), ``sid`` (``""`` when the token names none),
    ``claims`` (the verified logout token), ``product_sessions`` (the
    :class:`~workeasy360_sso.models.ProductSession` rows it ended).

``entitlement_checked``
    Sent each time the connector actually asked the platform about
    entitlement (never for an answer served from its cache), so a product can
    log or alert in its own format. ``outcome`` is ``"answer"`` (``answer`` is
    the new :class:`~workeasy360_sso.entitlements.Answer`, ``previous`` the one
    it replaced or ``None``), ``"outage"`` (``detail`` says why; the last
    answer stands) or ``"refused"`` (the platform refused this product's own
    client; ``rate_limited`` is true when a 429 was read as a refusal).

    Keyword arguments: ``config``, ``organization_id``, ``subject``,
    ``background``, ``outcome``, ``answer``, ``previous``, ``detail``,
    ``rate_limited``, ``context`` (whatever the caller passed to
    :func:`~workeasy360_sso.entitlements.check` as ``context``, or ``None``).
    Exceptions raised by receivers are logged and ignored: observing an
    answer must never change it.
"""

from __future__ import annotations

from django.dispatch import Signal

backchannel_logout = Signal()
entitlement_checked = Signal()
