"""Completing a sign-in: the callback's whole decision, in order.

1. Consume the pending flow first, whatever happens next.
2. A provider ``error`` becomes a fixed code.
3. No flow for this ``state`` in this browser: ``expired``.
4. A connector that is not configured refuses (``unavailable``) instead of
   talking to anything.
5. Exchange the code once, authenticated as this client, with the verifier.
6. Verify the ID token offline (``tokens.verify_id_token``).
7. Ecosystem checks: ``organization_id`` present; ``product_code`` is ours;
   the organization the launcher named, when it named one; a provider
   session already ended by back-channel logout is refused; for "confirm
   it's you", the subject is the one already signed in and, after
   ``prompt=login``, ``auth_time`` is no older than the request.
8. Resolve the local user on ``(issuer, sub)`` and bind the organization -
   one database transaction, so a binding the product refuses leaves no
   half-made account behind.
9. A fresh product session (no fixation); a different person's previous
   session in this browser is ended server-side first.

Every refusal is a :class:`~workeasy360_sso.errors.SignInRefused` carrying a
``stage`` (and, from the provider, ``provider_error``/``http_status``), so a
product can map it onto its own vocabulary.
"""

from __future__ import annotations

import logging
import time
import uuid
from dataclasses import dataclass
from datetime import datetime
from datetime import timezone as dt_timezone
from typing import Any

from django.contrib.auth import login
from django.contrib.auth.base_user import AbstractBaseUser
from django.db import transaction
from django.http import HttpRequest

from workeasy360_sso import client_auth, discovery, http, sessions, tokens
from workeasy360_sso.conf import SSOConfig
from workeasy360_sso.errors import (
    STAGE_ADAPTER,
    STAGE_AUTHORIZATION,
    STAGE_BINDING,
    STAGE_CONFIGURATION,
    STAGE_FLOW,
    STAGE_ID_TOKEN,
    STAGE_REAUTHENTICATION,
    STAGE_TOKEN,
    SignInRefused,
    provider_error_code,
)
from workeasy360_sso.flow import consume, parse_uuid
from workeasy360_sso.models import FederatedIdentity, PendingSignIn, ProductSession
from workeasy360_sso.organizations import SESSION_KEY, get_organization_adapter
from workeasy360_sso.provisioning import get_user_adapter

logger = logging.getLogger("workeasy360_sso")

BACKEND = "workeasy360_sso.backends.WorkEasy360Backend"
REAUTH_SESSION_KEY = "workeasy360_sso_reauthenticated_at"

#: What a successful "confirm it's you" does (``complete(..., reauthentication=)``).
#: ``confirm``: record the confirmation in the session and change nothing else.
#: ``sign_in``: sign the same person in again - a fresh session, the product's
#: adapters run again - for products that record authentication at sign-in.
REAUTH_CONFIRM = "confirm"
REAUTH_SIGN_IN = "sign_in"


@dataclass(frozen=True)
class SignInResult:
    flow: PendingSignIn
    claims: dict[str, Any]
    user: AbstractBaseUser | None
    identity: FederatedIdentity | None
    organization_id: uuid.UUID
    product_session: ProductSession | None
    reauthenticated: bool = False
    #: Whatever the organization adapter's ``bind`` returned (the product's
    #: tenant or membership, say); ``None`` for a plain confirmation.
    binding: Any = None


def _aal(value: Any) -> int:
    """The ``aal`` claim as 1 or 2; anything else is the lowest assurance."""
    if isinstance(value, bool):
        return 1
    if isinstance(value, int) and value in (1, 2):
        return value
    if isinstance(value, str) and value.strip() in ("1", "2"):
        return int(value.strip())
    return 1


def complete(
    config: SSOConfig, request: HttpRequest, *, reauthentication: str = REAUTH_CONFIRM
) -> SignInResult:
    if reauthentication not in (REAUTH_CONFIRM, REAUTH_SIGN_IN):
        raise ValueError(f"unknown reauthentication mode {reauthentication!r}")
    params = request.GET
    flow = consume(request, params.get("state", ""))
    error = str(params.get("error") or "")[:64]
    if flow is None:
        if error:
            raise SignInRefused(
                provider_error_code(error),
                log_reason="no_pending_flow",
                stage=STAGE_AUTHORIZATION,
                provider_error=error,
            )
        raise SignInRefused("expired", log_reason="no_pending_flow", stage=STAGE_FLOW)
    if error:
        raise SignInRefused(
            provider_error_code(error),
            log_reason=f"provider_{error}"[:64],
            stage=STAGE_AUTHORIZATION,
            provider_error=error,
        )
    if not config.is_configured:
        raise SignInRefused("unavailable", log_reason="not_configured", stage=STAGE_CONFIGURATION)
    code = params.get("code", "")
    if not code or len(code) > 4096:
        raise SignInRefused("expired", log_reason="no_code", stage=STAGE_FLOW)

    token_response = exchange_code(config, code=code, code_verifier=flow.code_verifier)
    try:
        claims = tokens.verify_id_token(
            config, str(token_response.get("id_token") or ""), nonce=flow.nonce
        )
    except tokens.TokenRejected as exc:
        code_for = "expired" if exc.reason == "expired" else "refused"
        raise SignInRefused(
            code_for, log_reason=f"id_token_{exc.reason}", stage=STAGE_ID_TOKEN
        ) from exc
    except discovery.DiscoveryError as exc:
        raise SignInRefused(
            "unavailable", log_reason="jwks_unavailable", stage=STAGE_ID_TOKEN
        ) from exc

    organization_id = parse_uuid(claims.get("organization_id"))
    if organization_id is None:
        raise SignInRefused("refused", log_reason="no_organization_claim", stage=STAGE_BINDING)
    if claims.get("product_code") != config.product_code:
        raise SignInRefused("wrong_product", stage=STAGE_BINDING)
    if flow.organization_hint and organization_id != flow.organization_hint:
        raise SignInRefused("wrong_organization", stage=STAGE_BINDING)
    provider_sid = str(claims.get("sid") or "")
    if provider_sid and sessions.provider_session_ended(issuer=config.issuer, sid=provider_sid):
        raise SignInRefused("session_ended", stage=STAGE_BINDING)

    if flow.reauth_subject:
        # "Confirm it's you": prove the person at the keyboard is the one
        # already signed in. A different account confirms nothing; the
        # existing session is left exactly as it was. Checked before the
        # freshness of the sign-in: "that was someone else" is the more
        # useful thing to tell the person.
        signed_in_elsewhere = reauthentication == REAUTH_CONFIRM and not request.user.is_authenticated
        if claims["sub"] != flow.reauth_subject or signed_in_elsewhere:
            raise SignInRefused(
                "reauthentication_failed",
                log_reason="different_subject",
                stage=STAGE_REAUTHENTICATION,
            )

    if "login" in flow.prompt.split():
        auth_time = claims.get("auth_time")
        not_before = flow.created_at.timestamp() - config.leeway
        if (
            isinstance(auth_time, bool)
            or not isinstance(auth_time, (int, float))
            or auth_time < not_before
        ):
            raise SignInRefused(
                "reauthentication_failed",
                log_reason="stale_auth_time",
                stage=STAGE_REAUTHENTICATION,
            )

    if flow.reauth_subject and reauthentication == REAUTH_CONFIRM:
        request.session[REAUTH_SESSION_KEY] = int(time.time())
        return SignInResult(flow, claims, request.user, None, organization_id, None, True)

    try:
        with transaction.atomic():
            user, identity = get_user_adapter(config).resolve(request, claims=claims)
            binding = get_organization_adapter(config).bind(
                request, user=user, organization_id=organization_id, claims=claims
            )
    except SignInRefused as refusal:
        if not refusal.stage:
            refusal.stage = STAGE_ADAPTER
        raise
    product_session = _open_session(
        config,
        request,
        user=user,
        identity=identity,
        claims=claims,
        organization_id=organization_id,
        provider_sid=provider_sid,
    )
    reauthenticated = bool(flow.reauth_subject)
    if reauthenticated:
        request.session[REAUTH_SESSION_KEY] = int(time.time())
    logger.info(
        "workeasy360_sso.signed_in",
        extra={
            "subject": claims["sub"],
            "organization_id": str(organization_id),
            "user_id": str(user.pk),
        },
    )
    return SignInResult(
        flow,
        claims,
        user,
        identity,
        organization_id,
        product_session,
        reauthenticated,
        binding,
    )


def exchange_code(config: SSOConfig, *, code: str, code_verifier: str) -> dict[str, Any]:
    try:
        url = discovery.endpoint(config, "token_endpoint")
        fields, headers = client_auth.authentication(config)
    except discovery.DiscoveryError as exc:
        raise SignInRefused(
            "unavailable", log_reason="discovery_unavailable", stage=STAGE_TOKEN
        ) from exc
    data = {
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": config.redirect_uri,
        "code_verifier": code_verifier,
        **fields,
    }
    try:
        response = http.post_form(config, url, data, headers)
    except http.ProviderUnavailable as exc:
        raise SignInRefused(
            "unavailable", log_reason="token_endpoint_unreachable", stage=STAGE_TOKEN
        ) from exc

    status = response.status_code
    try:
        payload = response.json()
    except ValueError:
        payload = None
    error = ""
    if isinstance(payload, dict):
        error = str(payload.get("error") or "")[:64]
    if status == 429:
        raise SignInRefused(
            "rate_limited", stage=STAGE_TOKEN, provider_error=error, http_status=status
        )
    if status >= 500:
        raise SignInRefused(
            "unavailable",
            log_reason=f"token_http_{status}",
            stage=STAGE_TOKEN,
            provider_error=error,
            http_status=status,
        )
    if payload is None:
        raise SignInRefused(
            "unavailable", log_reason="token_not_json", stage=STAGE_TOKEN, http_status=status
        )
    if status != 200 or not isinstance(payload, dict):
        raise SignInRefused(
            provider_error_code(error),
            log_reason=f"token_{error}"[:64],
            stage=STAGE_TOKEN,
            provider_error=error,
            http_status=status,
        )
    if str(payload.get("token_type", "")).lower() != "bearer" or not payload.get("id_token"):
        raise SignInRefused(
            "refused",
            log_reason="token_response_incomplete",
            stage=STAGE_TOKEN,
            http_status=status,
        )
    return payload


def _open_session(
    config: SSOConfig,
    request: HttpRequest,
    *,
    user: AbstractBaseUser,
    identity: FederatedIdentity,
    claims: dict[str, Any],
    organization_id: uuid.UUID,
    provider_sid: str,
) -> ProductSession:
    previous = request.session.get(SESSION_KEY)
    if isinstance(previous, dict) and previous.get("product_session_id"):
        # Whoever was signed in here before - the same person or another
        # account - that session is replaced, never inherited.
        sessions.end_one(previous["product_session_id"], reason=ProductSession.EndReason.REPLACED)

    # A different user's session is flushed - deleted server-side - so nothing
    # is inherited; login() cycles the key of an anonymous session. It keeps
    # the key when the same person was already signed in, so that is cycled
    # here: whatever came before, the session id after a sign-in is new.
    before = request.session.session_key
    if request.user.is_authenticated and request.user.pk != user.pk:
        request.session.flush()
    login(request, user, backend=config.login_backend)
    if before and request.session.session_key == before:
        request.session.cycle_key()
    if not request.session.session_key:
        request.session.save()

    auth_time = claims.get("auth_time")
    has_auth_time = isinstance(auth_time, (int, float)) and not isinstance(auth_time, bool)
    product_session = sessions.record_sign_in(
        identity=identity,
        session_key=request.session.session_key or "",
        provider_sid=provider_sid,
        organization_id=organization_id,
        auth_time=(
            datetime.fromtimestamp(int(auth_time), tz=dt_timezone.utc) if has_auth_time else None
        ),
    )
    request.session[SESSION_KEY] = {
        "subject": claims["sub"],
        "organization_id": str(organization_id),
        "organization_name": str(claims.get("organization_name") or ""),
        "product_code": config.product_code,
        "aal": _aal(claims.get("aal")),
        "auth_time": int(auth_time) if has_auth_time else None,
        "provider_sid": provider_sid,
        "product_session_id": str(product_session.id),
    }
    return product_session
