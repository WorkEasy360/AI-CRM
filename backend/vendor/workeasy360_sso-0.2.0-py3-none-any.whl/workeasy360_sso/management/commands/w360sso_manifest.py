"""Print the integration manifest this product should register.

Everything is derived from the connector's configuration and the URLconf, so
the registered redirect URI, post-logout URI and back-channel logout URI are
exactly the routes this deployment serves - the exact-match rule leaves no
room for a hand-typed difference. A deployment pipeline can submit the
output to the Super Admin registration API unchanged.
"""

from __future__ import annotations

import json
from urllib.parse import urlsplit

from django.core.management.base import BaseCommand, CommandError
from django.urls import NoReverseMatch, reverse

from workeasy360_sso.conf import get_config

#: The platform's manifest that adds ``backchannel_logout_uri``.
BACKCHANNEL_MANIFEST_VERSION = "2026-11-15"
CURRENT_PLATFORM_MANIFEST_VERSION = "2026-10-12"


class Command(BaseCommand):
    help = "Print the Workeasy360 integration manifest for this deployment as JSON."

    def add_arguments(self, parser):
        parser.add_argument("--display-name", default="")
        parser.add_argument("--launch-url", default="", help="Default: the redirect URI's origin + '/'.")
        parser.add_argument("--login-url", default="", help="Your own sign-in page (sso_optional only).")
        parser.add_argument("--health-url", default="")
        parser.add_argument("--contact-email", default="")
        parser.add_argument(
            "--manifest-version",
            default=BACKCHANNEL_MANIFEST_VERSION,
            choices=(CURRENT_PLATFORM_MANIFEST_VERSION, BACKCHANNEL_MANIFEST_VERSION),
        )

    def handle(self, *args, **options):
        config = get_config()
        if not config.redirect_uri or not config.product_code:
            raise CommandError("Set WORKEASY360_REDIRECT_URI and WORKEASY360_PRODUCT_CODE first.")
        origin = "{0.scheme}://{0.netloc}".format(urlsplit(config.redirect_uri))
        manifest = {
            "manifest_version": options["manifest_version"],
            "product_code": config.product_code,
            "launch_url": options["launch_url"] or f"{origin}/",
            "redirect_uris": [config.redirect_uri],
            "post_logout_redirect_uris": (
                [config.post_logout_redirect_uri] if config.post_logout_redirect_uri else []
            ),
            "scopes": list(config.scopes),
            "token_endpoint_auth_method": (
                "private_key_jwt" if config.uses_private_key_jwt or not config.client_secret else "client_secret_basic"
            ),
            "sign_in_mode": "sso_only" if config.sso_only else "sso_optional",
        }
        if options["display_name"]:
            manifest["display_name"] = options["display_name"]
        if not config.sso_only:
            login_url = options["login_url"]
            if not login_url:
                raise CommandError("sso_optional needs --login-url (your own sign-in page).")
            manifest["login_url"] = login_url
        if options["health_url"]:
            manifest["health_url"] = options["health_url"]
        if options["contact_email"]:
            manifest["contact_email"] = options["contact_email"]
        if options["manifest_version"] == BACKCHANNEL_MANIFEST_VERSION and config.backchannel_logout:
            try:
                manifest["backchannel_logout_uri"] = origin + reverse("workeasy360_sso:backchannel_logout")
            except NoReverseMatch as exc:
                raise CommandError(
                    "WORKEASY360_BACKCHANNEL_LOGOUT is on but no workeasy360_sso:backchannel_logout route "
                    "is mounted."
                ) from exc
        self.stdout.write(json.dumps(manifest, indent=2))
