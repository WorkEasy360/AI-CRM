"""Generate this product's ``private_key_jwt`` key pair.

The private key stays with the product (a secret store, or a file only the
application user can read). The public key is what an operator registers in
the Super Admin console (Products -> Authentication -> add public key); the
platform answers with the credential id, which becomes WORKEASY360_KEY_ID.
"""

from __future__ import annotations

import os
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec, rsa
from django.core.management.base import BaseCommand, CommandError


class Command(BaseCommand):
    help = "Generate a private key (kept by the product) and print its public key (registered with Workeasy360)."

    def add_arguments(self, parser):
        parser.add_argument("--out", required=True, help="Where to write the private key PEM.")
        parser.add_argument("--algorithm", choices=("RS256", "ES256"), default="RS256")
        parser.add_argument("--public-out", help="Also write the public key PEM here.")
        parser.add_argument("--force", action="store_true", help="Overwrite an existing file.")

    def handle(self, *args, **options):
        out = Path(options["out"])
        if out.exists() and not options["force"]:
            raise CommandError(f"{out} exists; refusing to overwrite a key (use --force).")
        if options["algorithm"] == "RS256":
            key = rsa.generate_private_key(public_exponent=65537, key_size=3072)
        else:
            key = ec.generate_private_key(ec.SECP256R1())

        private_pem = key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8,
            serialization.NoEncryption(),
        )
        public_pem = key.public_key().public_bytes(
            serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo
        )
        out.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(out, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "wb") as handle:
            handle.write(private_pem)
        if options.get("public_out"):
            Path(options["public_out"]).write_bytes(public_pem)

        self.stdout.write(f"Private key written to {out} (keep it secret; set WORKEASY360_PRIVATE_KEY_FILE).")
        self.stdout.write(f"Signing algorithm: {options['algorithm']} (set WORKEASY360_SIGNING_ALGORITHM).")
        self.stdout.write("Register this PUBLIC key with Workeasy360:\n")
        self.stdout.write(public_pem.decode("ascii"))
