"""Delete connector rows nobody needs any more. Safe to run from cron hourly."""

from __future__ import annotations

from datetime import timedelta

from django.core.management.base import BaseCommand
from django.utils import timezone

from workeasy360_sso.flow import purge_expired
from workeasy360_sso.models import EndedProviderSession, ProductSession, ReceivedLogoutToken
from workeasy360_sso.sessions import _session_store


class Command(BaseCommand):
    help = "Purge expired sign-in flows, spent logout-token ids and old ended sessions."

    def add_arguments(self, parser):
        parser.add_argument("--keep-ended-sessions-days", type=int, default=30)

    def handle(self, *args, **options):
        now = timezone.now()
        keep = timedelta(days=options["keep_ended_sessions_days"])
        flows = purge_expired()
        # A logout token lives for minutes; a day of jti memory is ample.
        jtis, _ = ReceivedLogoutToken.objects.filter(received_at__lt=now - timedelta(days=1)).delete()
        # An ended provider session only matters while a sign-in begun before
        # it ended could still complete: code 60 s + ID token 300 s.
        sids, _ = EndedProviderSession.objects.filter(ended_at__lt=now - timedelta(days=1)).delete()
        sessions, _ = ProductSession.objects.filter(ended_at__lt=now - keep).delete()
        # A session that expired (or was cleared) without a sign-out leaves its
        # record open; once the session itself is gone there is nothing left
        # for a back-channel logout to end.
        store = _session_store()()
        gone = [
            row.pk
            for row in ProductSession.objects.filter(ended_at__isnull=True, created_at__lt=now - keep)
            .only("pk", "session_key")
            .iterator()
            if not store.exists(row.session_key)
        ]
        stale, _ = ProductSession.objects.filter(pk__in=gone).delete()
        self.stdout.write(
            f"purged flows={flows} logout_jtis={jtis} ended_sids={sids} "
            f"ended_sessions={sessions} vanished_sessions={stale}"
        )
