"""Workeasy360 single sign-on connector for Django products.

One package that every Django product installs instead of writing its own
OpenID Connect client. It implements the Workeasy360 product contract
(platform docs ``phase-3/04``-``09`` and ``universal-sso/completion-design``
section 3-4) exactly once:

* authorization code flow with PKCE S256, ``state`` and ``nonce``;
* ``private_key_jwt`` (or ``client_secret_basic``) client authentication;
* offline ID-token verification - key by ``kid``, algorithm from the key set,
  ``iss``/``aud``/``typ``/``jti``/``nonce``/``product_code``/organization;
* identity linking on ``(issuer, sub)``, never on an email address;
* an organization-bound product session;
* entitlement re-checks on the platform's advertised cadence;
* local sign-out, sign-out of the product *and* Workeasy360, and
  OpenID Connect Back-Channel Logout 1.0 for "sign out everywhere".

Nothing in this package names a product. A product supplies its issuer,
client id, credential, redirect URI and product code through configuration.
"""

__version__ = "0.2.0"
