"""The connector's own tables. They live in the product's database.

Nothing here copies platform data: a product stores which local user a
Workeasy360 subject is, which of its own sessions a Workeasy360 sign-in
opened (so a back-channel logout can end them), and the short-lived state of
sign-ins in progress.
"""

from __future__ import annotations

import uuid

from django.conf import settings
from django.db import models
from django.utils import timezone


class FederatedIdentity(models.Model):
    """A local user's verified Workeasy360 identity: ``(issuer, subject)``.

    Never the email address. The email is profile data a person can change;
    the subject is stable for the life of the account and never reused
    (contract 05 section 3).
    """

    class Status(models.TextChoices):
        ACTIVE = "active", "Active"
        SUSPENDED = "suspended", "Suspended"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="workeasy360_identities",
    )
    issuer = models.CharField(max_length=255)
    subject = models.CharField(max_length=255)
    status = models.CharField(max_length=16, choices=Status.choices, default=Status.ACTIVE)
    #: The address Workeasy360 reported when the link was made. Informational.
    email_at_link = models.CharField(max_length=254, blank=True, default="")
    linked_at = models.DateTimeField(default=timezone.now)
    last_sign_in_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "workeasy360_sso_federated_identity"
        constraints = [
            models.UniqueConstraint(
                fields=["issuer", "subject"], name="w360sso_identity_issuer_subject_uniq"
            ),
            models.UniqueConstraint(
                fields=["user", "issuer"], name="w360sso_identity_user_issuer_uniq"
            ),
        ]
        verbose_name = "Workeasy360 identity"
        verbose_name_plural = "Workeasy360 identities"

    def __str__(self) -> str:
        return f"{self.subject} @ {self.issuer}"


class PendingSignIn(models.Model):
    """One authorization request in flight: server-side, single use, short.

    The browser holds only ``state`` (in the URL) and a random binding cookie.
    The row stores hashes of both, so a database read yields neither, and the
    callback consumes the row atomically before it does anything else.
    """

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    state_hash = models.CharField(max_length=64, unique=True)
    binding_hash = models.CharField(max_length=64)
    nonce = models.CharField(max_length=128)
    code_verifier = models.CharField(max_length=128)
    organization_hint = models.UUIDField(null=True, blank=True)
    next_path = models.CharField(max_length=2048, blank=True, default="")
    prompt = models.CharField(max_length=64, blank=True, default="")
    #: For "confirm it's you" (prompt=login): the subject that must answer.
    reauth_subject = models.CharField(max_length=255, blank=True, default="")
    automatic = models.BooleanField(default=False)
    created_at = models.DateTimeField(default=timezone.now)
    expires_at = models.DateTimeField()
    consumed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "workeasy360_sso_pending_sign_in"
        indexes = [models.Index(fields=["expires_at"], name="w360sso_pending_expiry_idx")]


class ProductSession(models.Model):
    """A product session opened by a Workeasy360 sign-in.

    The back-channel logout target: a logout token names a provider session
    (``sid``) and/or a subject, and this table says which of the product's own
    sessions those are. ``session_key`` follows the product's session if its
    key is rotated later (the middleware keeps it current).
    """

    class EndReason(models.TextChoices):
        SIGNED_OUT = "signed_out", "Signed out of the product"
        SIGNED_OUT_WORKEASY360 = "signed_out_workeasy360", "Signed out of the product and Workeasy360"
        BACKCHANNEL = "backchannel_logout", "Workeasy360 ended the session"
        REPLACED = "replaced", "Another sign-in replaced it"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    identity = models.ForeignKey(
        FederatedIdentity, on_delete=models.CASCADE, related_name="sessions"
    )
    session_key = models.CharField(max_length=64, db_index=True)
    provider_sid = models.CharField(max_length=255, blank=True, default="", db_index=True)
    #: The Workeasy360 organization the sign-in was bound to. Its column is
    #: ``workeasy360_organization_id``: products commonly treat every
    #: ``organization_id`` column as their own tenant key (row-level security
    #: audits, tenant managers), and this one is not theirs.
    organization_id = models.UUIDField(db_column="workeasy360_organization_id")
    auth_time = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(default=timezone.now)
    ended_at = models.DateTimeField(null=True, blank=True)
    end_reason = models.CharField(max_length=32, choices=EndReason.choices, blank=True, default="")

    class Meta:
        db_table = "workeasy360_sso_product_session"
        indexes = [
            models.Index(fields=["identity", "ended_at"], name="w360sso_session_identity_idx"),
        ]


class ReceivedLogoutToken(models.Model):
    """``jti`` of every accepted logout token, so none is accepted twice."""

    jti = models.CharField(max_length=255, primary_key=True)
    issuer = models.CharField(max_length=255)
    received_at = models.DateTimeField(default=timezone.now, db_index=True)

    class Meta:
        db_table = "workeasy360_sso_received_logout_token"


class EndedProviderSession(models.Model):
    """A provider session (``sid``) Workeasy360 has ended.

    Kept so a sign-in that was already in flight when the logout arrived -
    its ID token still names the ended ``sid`` - is refused rather than
    opening a fresh session the logout was meant to prevent.
    """

    issuer = models.CharField(max_length=255)
    provider_sid = models.CharField(max_length=255)
    ended_at = models.DateTimeField(default=timezone.now, db_index=True)

    class Meta:
        db_table = "workeasy360_sso_ended_provider_session"
        constraints = [
            models.UniqueConstraint(
                fields=["issuer", "provider_sid"], name="w360sso_ended_sid_uniq"
            )
        ]
