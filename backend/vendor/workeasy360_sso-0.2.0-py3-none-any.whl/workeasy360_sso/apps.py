from __future__ import annotations

import sys

from django.apps import AppConfig
from django.conf import settings
from django.core.exceptions import ImproperlyConfigured


class WorkEasy360SSOConfig(AppConfig):
    name = "workeasy360_sso"
    label = "workeasy360_sso"
    verbose_name = "Workeasy360 single sign-on"
    default_auto_field = "django.db.models.BigAutoField"

    def ready(self) -> None:
        from django.contrib.auth.signals import user_logged_out

        from workeasy360_sso import checks  # noqa: F401 - registers the system checks
        from workeasy360_sso import sessions
        from workeasy360_sso.conf import ConfigurationError, get_config

        # Whichever view signs a person out, the session's back-channel record ends with it.
        user_logged_out.connect(sessions.on_user_logged_out, dispatch_uid="workeasy360_sso.logged_out")

        try:
            config = get_config()
        except ConfigurationError as exc:
            if not settings.DEBUG and _is_server_process():
                raise ImproperlyConfigured(f"workeasy360-sso: {exc}") from exc
            return  # reported by system check workeasy360_sso.E001
        # completion-design 3.1: production refuses to start while SSO is the
        # only way in and the configuration is unusable. Management commands
        # that only build or inspect (migrations, collectstatic, the
        # connector's own key generator) are allowed to run.
        if config.sso_only and not settings.DEBUG and config.problems and _is_server_process():
            raise ImproperlyConfigured(
                "workeasy360-sso: SSO-only and misconfigured: " + " ".join(config.problems)
            )


_BUILD_COMMANDS = {
    "makemigrations",
    "migrate",
    "collectstatic",
    "check",
    "compilemessages",
    "w360sso_keygen",
    "w360sso_manifest",
    "test",
    "shell",
}


def _is_server_process() -> bool:
    argv = sys.argv
    if len(argv) >= 2 and argv[0].endswith("manage.py"):
        return argv[1] not in _BUILD_COMMANDS
    return True
