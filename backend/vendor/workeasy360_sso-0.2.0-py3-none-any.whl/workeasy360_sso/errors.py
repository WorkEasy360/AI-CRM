"""The fixed vocabulary of sign-in outcomes a product shows a person.

The codes are the ones every Workeasy360 product already uses
(completion-design section 3.11), so a product moving onto this connector
keeps its messages. A code is safe to put in a URL and a log line; it never
carries a token, a code, a state, a nonce or a provider description.

A product whose own rules refuse a sign-in for a reason this vocabulary has
no word for (its own seat limit, say) registers that code, with the message
the built-in error page shows, in ``WORKEASY360_SSO["ERROR_MESSAGES"]``. Any
other unknown code is reported as ``refused``.
"""

from __future__ import annotations

import re
from typing import Any

from django.utils.translation import gettext_lazy as _

MESSAGES = {
    "cancelled": _("Sign-in was cancelled. You can try again."),
    "expired": _("The sign-in took too long or was already used. Please try again."),
    "unavailable": _("Workeasy360 sign-in is temporarily unavailable. Please try again shortly."),
    "refused": _("This product could not complete sign-in with Workeasy360. Contact support."),
    "rate_limited": _("Too many sign-in attempts. Wait a minute and try again."),
    "not_entitled": _("Your organization does not have access to this product yet."),
    "no_seat": _("You do not have a seat for this product. Ask an administrator for one."),
    "provider_membership_inactive": _(
        "You are not an active member of that organization in Workeasy360."
    ),
    "organization_inactive": _("That organization cannot be signed in to right now."),
    "access_policy": _(
        "Your organization's sign-in policy refused this session. Open Workeasy360 for details."
    ),
    "email_missing": _("Workeasy360 did not share an email address for this account."),
    "email_unverified": _("Verify your email address in Workeasy360, then try again."),
    "account_conflict": _(
        "An account with this email already exists here and is not linked to your "
        "Workeasy360 account. Contact your administrator."
    ),
    "account_disabled": _("Your account for this product is disabled."),
    "membership_inactive": _("Your access to this organization has ended."),
    "wrong_product": _("The sign-in was issued for a different product."),
    "wrong_organization": _("The sign-in was for a different organization than the one requested."),
    "reauthentication_failed": _(
        "Confirmation needs the same account that is signed in here, signed in just now."
    ),
    "session_ended": _("Your Workeasy360 session was ended. Please sign in again."),
}

#: Provider ``error`` values (contract 04 section 7) mapped to the vocabulary.
PROVIDER_ERRORS = {
    "access_denied": "cancelled",
    "login_required": "expired",
    "interaction_required": "expired",
    "invalid_grant": "expired",
    "temporarily_unavailable": "unavailable",
    "server_error": "unavailable",
    "product_not_entitled": "not_entitled",
    "product_no_seat": "no_seat",
    "no_seat": "no_seat",
    "membership_inactive": "provider_membership_inactive",
    "organization_inactive": "organization_inactive",
    "access_policy_denied": "access_policy",
    "organization_required": "refused",
    "invalid_request": "refused",
    "invalid_client": "refused",
    "invalid_scope": "refused",
    "unauthorized_client": "refused",
    "integration_suspended": "refused",
    "unsupported_response_type": "refused",
}

#: What a product-defined code must look like: safe in a URL, a log line and a template.
CODE_RE = re.compile(r"^[a-z][a-z0-9_]{1,63}$")

# Where in the sign-in a refusal happened (``SignInRefused.stage``). Stable values a
# product can branch on when it maps refusals onto its own vocabulary.
STAGE_START = "start"  # starting a sign-in: the provider's metadata could not be read
STAGE_AUTHORIZATION = "authorization"  # the provider redirected back with ``error=``
STAGE_FLOW = "flow"  # no pending flow for this state in this browser, or no code
STAGE_CONFIGURATION = "configuration"  # the connector is not configured
STAGE_TOKEN = "token"  # discovery or the token endpoint
STAGE_ID_TOKEN = "id_token"  # offline ID-token verification
STAGE_BINDING = "binding"  # organization, product, ended provider session
STAGE_REAUTHENTICATION = "reauthentication"  # "confirm it's you"
STAGE_ADAPTER = "adapter"  # the product's user or organization adapter


def provider_error_code(error: str) -> str:
    return PROVIDER_ERRORS.get(str(error or ""), "refused")


def product_messages() -> dict[str, Any]:
    """Codes (and messages) the product registered in ``ERROR_MESSAGES``."""
    from workeasy360_sso.conf import ConfigurationError, get_config

    try:
        return dict(get_config().error_messages)
    except ConfigurationError:
        return {}


def is_known_code(code: str) -> bool:
    return code in MESSAGES or code in product_messages()


def message_for(code: str) -> str:
    """The product's message for ``code`` if it registered one, else the connector's."""
    custom = product_messages()
    if code in custom:
        return str(custom[code])
    return str(MESSAGES.get(code, MESSAGES["refused"]))


class SignInRefused(Exception):
    """A sign-in that must not complete.

    ``code`` is from :data:`MESSAGES` or a code the product registered in
    ``ERROR_MESSAGES``; anything else becomes ``refused``. The other
    attributes say *why* without carrying anything secret, so a product can
    map refusals onto its own vocabulary and logs:

    * ``log_reason`` (also ``reason``): a fixed, loggable string;
    * ``stage``: one of the ``STAGE_*`` constants of this module;
    * ``provider_error``: the provider's OAuth ``error`` value (at most 64
      characters) when the authorization response or the token endpoint
      carried one, else ``""``;
    * ``http_status``: the token endpoint's status code, when it answered.
    """

    def __init__(
        self,
        code: str,
        *,
        log_reason: str = "",
        stage: str = "",
        provider_error: str = "",
        http_status: int | None = None,
    ) -> None:
        if not (isinstance(code, str) and is_known_code(code)):
            code = "refused"
        super().__init__(code)
        self.code = code
        self.log_reason = log_reason or code
        self.stage = stage
        self.provider_error = str(provider_error or "")[:64]
        self.http_status = http_status

    @property
    def reason(self) -> str:
        return self.log_reason
