"""Starting an authorization request and consuming it on the callback.

completion-design section 3.3-3.4: ``state`` and ``nonce`` of 32 random bytes,
a PKCE S256 verifier, ``organization`` forwarded only when it is a UUID; the
pending flow server-side, single use, ten minutes, bound to this browser; on
the callback the flow is consumed **first**, whatever happens next.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import uuid
from dataclasses import dataclass
from datetime import timedelta
from urllib.parse import urlencode

from django.http import HttpRequest, HttpResponse
from django.utils import timezone

from workeasy360_sso import discovery
from workeasy360_sso.conf import ALLOWED_PROMPTS, SSOConfig
from workeasy360_sso.models import PendingSignIn

BINDING_COOKIE = "w360sso_bind"
SECURE_BINDING_COOKIE = "__Host-w360sso_bind"
PURGE_ONE_IN = 50


def _sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def pkce_challenge(verifier: str) -> str:
    """RFC 7636 4.2: BASE64URL(SHA256(verifier)), unpadded."""
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    return base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")


def parse_uuid(value: object) -> uuid.UUID | None:
    if not isinstance(value, str) or len(value) > 64:
        return None
    try:
        return uuid.UUID(value)
    except ValueError:
        return None


def normalise_prompt(value: str | None) -> str:
    """A space-separated ``prompt`` of known values, or ``""``.

    ``none`` combined with anything else is invalid (OIDC Core 3.1.2.1); it is
    dropped here rather than sent, so a product bug cannot become a provider
    ``invalid_request`` the person sees.
    """
    if not value:
        return ""
    parts = [part for part in str(value).split() if part in ALLOWED_PROMPTS]
    parts = list(dict.fromkeys(parts))
    if "none" in parts and len(parts) > 1:
        return ""
    return " ".join(parts)


def binding_cookie_name(request: HttpRequest) -> str:
    return SECURE_BINDING_COOKIE if request.is_secure() else BINDING_COOKIE


def _binding_value(request: HttpRequest) -> tuple[str, bool]:
    """This browser's binding value, and whether it must be (re)set."""
    current = request.COOKIES.get(binding_cookie_name(request), "")
    if 32 <= len(current) <= 128 and current.replace("-", "").replace("_", "").isalnum():
        return current, False
    return secrets.token_urlsafe(32), True


@dataclass(frozen=True)
class AuthorizationRequest:
    url: str
    binding: str
    set_binding_cookie: bool


def begin(
    config: SSOConfig,
    request: HttpRequest,
    *,
    organization: str | None,
    next_path: str,
    prompt: str = "",
    reauth_subject: str = "",
    automatic: bool = False,
) -> AuthorizationRequest:
    state = secrets.token_urlsafe(32)
    nonce = secrets.token_urlsafe(32)
    verifier = secrets.token_urlsafe(32)  # 43 characters, RFC 7636 4.1
    binding, set_cookie = _binding_value(request)
    organization_id = parse_uuid(organization)
    prompt = normalise_prompt(prompt)
    now = timezone.now()

    # Starting a sign-in needs no session, so this table grows with anonymous
    # traffic. Purging expired rows on ~2% of starts bounds it to roughly one
    # flow lifetime of traffic even if w360sso_cleanup never runs; rate-limit
    # the start route at the reverse proxy as well.
    if secrets.randbelow(PURGE_ONE_IN) == 0:
        PendingSignIn.objects.filter(expires_at__lt=now).delete()

    PendingSignIn.objects.create(
        state_hash=_sha256(state),
        binding_hash=_sha256(binding),
        nonce=nonce,
        code_verifier=verifier,
        organization_hint=organization_id,
        next_path=next_path,
        prompt=prompt,
        reauth_subject=reauth_subject,
        automatic=automatic,
        created_at=now,
        expires_at=now + timedelta(seconds=config.flow_ttl),
    )

    query = {
        "response_type": "code",
        "client_id": config.client_id,
        "redirect_uri": config.redirect_uri,
        "scope": config.scope,
        "state": state,
        "nonce": nonce,
        "code_challenge": pkce_challenge(verifier),
        "code_challenge_method": "S256",
    }
    if organization_id is not None:
        query["organization"] = str(organization_id)
    if prompt:
        query["prompt"] = prompt
    authorize = discovery.endpoint(config, "authorization_endpoint")
    separator = "&" if "?" in authorize else "?"
    return AuthorizationRequest(
        url=f"{authorize}{separator}{urlencode(query)}",
        binding=binding,
        set_binding_cookie=set_cookie,
    )


def set_binding_cookie(response: HttpResponse, request: HttpRequest, value: str) -> None:
    # A browser-session cookie: SameSite=Lax is sent on the top-level redirect
    # back from Workeasy360, which is the only request that needs it.
    response.set_cookie(
        binding_cookie_name(request),
        value,
        secure=request.is_secure(),
        httponly=True,
        samesite="Lax",
        path="/",
    )


def consume(request: HttpRequest, state: str) -> PendingSignIn | None:
    """Spend the pending flow for ``state``, or return ``None``.

    The ``UPDATE ... WHERE consumed_at IS NULL`` is the single-use guarantee:
    of two concurrent callbacks carrying the same state, exactly one row
    update succeeds. A flow whose binding cookie does not match this browser
    is spent too - a stolen callback URL opened elsewhere burns the flow
    rather than leaving it for a second attempt.
    """
    if not state or len(state) > 512:
        return None
    state_hash = _sha256(state)
    now = timezone.now()
    spent = PendingSignIn.objects.filter(
        state_hash=state_hash, consumed_at__isnull=True, expires_at__gt=now
    ).update(consumed_at=now)
    if spent != 1:
        return None
    flow = PendingSignIn.objects.get(state_hash=state_hash)
    binding = request.COOKIES.get(binding_cookie_name(request), "")
    if not binding or not hmac.compare_digest(_sha256(binding), flow.binding_hash):
        return None
    return flow


def purge_expired(*, older_than: timedelta = timedelta(hours=1)) -> int:
    cutoff = timezone.now() - older_than
    deleted, _ = PendingSignIn.objects.filter(expires_at__lt=cutoff).delete()
    return deleted
